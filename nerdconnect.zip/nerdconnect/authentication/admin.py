from django.contrib import admin
from .models import Details

admin.site.register(Details)
